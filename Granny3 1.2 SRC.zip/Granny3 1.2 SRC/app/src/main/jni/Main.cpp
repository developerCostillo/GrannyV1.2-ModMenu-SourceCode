#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "Unity/Quaternion.h"
#include "Unity/Vector2.h"
#include "Unity/Vector3.h"
#include "Unity/Unity.h"

#include "KittyMemory/MemoryPatch.h"
#include "Menu.h"

#include "Includes/Chams.h"

//Target lib here
#define targetLibName OBFUSCATE("libil2cpp.so")

#include "Includes/Macros.h"
#include <ctime>

void *(*Instantiate)(void*, Vector3 pos, Quaternion rot);
Vector3 (*get_forward)(void* transform);
Vector3 (*get_position)(void* transform);
Quaternion (*get_rotation)(void* transform);
void *(*get_transform_GameObject)(void* gameObject);

Vector3 getPosition(void *transform)
{
    return get_position(get_transform_GameObject(transform));
} 

struct GrannyItemPointers { 
    void* newgatefuse;      // 0x88
    void* newshotgun;       // 0xB8
    void* newteddy;         // 0xC4
    void* newmatches;       // 0xCC
    void* newfirewood;      // 0xDC
    void* newbridgecrank;   // 0xEC
    void* newplanka;        // 0x108
    void* newsafekey;       // 0x114
    void* newslingshot;     // 0x124
    void* newvas;          // 0x130
    void* newvas2;         // 0x13C
    void* newshedkey;       // 0x148
    void* newpadlockkey;    // 0x154
    void* newgencable;      // 0x160
    void* newcoconuty;      // 0x170
    void* newweaponkey;     // 0x184
    void* newcoin;          // 0x19C
    void* newelectricSwitch; // 0x1AC
    void* newtrainkey;      // 0x1B8
    void* newaccelerator;   // 0x1C4
    void* newdoorActivator; // 0x1D0
    void* newcrowbar;       // 0x1E8
} Items;


void* itemPointers[] = { 
    &Items.newgatefuse,      
    &Items.newshotgun,       
    &Items.newteddy,         
    &Items.newmatches,       
    &Items.newfirewood,      
    &Items.newbridgecrank,   
    &Items.newplanka,        
    &Items.newsafekey,       
    &Items.newslingshot,     
    &Items.newvas,          
    &Items.newvas2,         
    &Items.newshedkey,       
    &Items.newpadlockkey,    
    &Items.newgencable,      
    &Items.newcoconuty,      
    &Items.newweaponkey,     
    &Items.newcoin,          
    &Items.newelectricSwitch,
    &Items.newtrainkey,      
    &Items.newaccelerator,   
    &Items.newdoorActivator, 
    &Items.newcrowbar        
};


// Globals
void* SelectedItem;
bool SpawnButtonClicked = false;

void SpawnItem(void* player) {
    if (player) {
        void* plyrTransform = get_transform_GameObject(player);

        if (plyrTransform) {
            Vector3 pos = get_position(plyrTransform);
            Quaternion rot = get_rotation(plyrTransform);
            Vector3 itemPositionFront = pos + (get_forward(plyrTransform) * 3);

            if (SelectedItem != nullptr) {
                Instantiate(SelectedItem, itemPositionFront, rot);
            }
        }
    }
}


void (*old_PickUp_Update)(void* _);
void PickUp_Update(void* _) {
    if (!_)
        return;
        
    // public class PickUpSystem   (Name Will be Different For Your Game 🤡 Find it by yourself)

    // Updating the offsets based on the new item list
    Items.newgatefuse = *(void**)((uint64_t)_ + 0x88);
    Items.newshotgun = *(void**)((uint64_t)_ + 0xB8);
    Items.newteddy = *(void**)((uint64_t)_ + 0xC4);
    Items.newmatches = *(void**)((uint64_t)_ + 0xCC);
    Items.newfirewood = *(void**)((uint64_t)_ + 0xDC);
    Items.newbridgecrank = *(void**)((uint64_t)_ + 0xEC);
    Items.newplanka = *(void**)((uint64_t)_ + 0x108);
    Items.newsafekey = *(void**)((uint64_t)_ + 0x114);
    Items.newslingshot = *(void**)((uint64_t)_ + 0x124);
    Items.newvas = *(void**)((uint64_t)_ + 0x130);
    Items.newvas2 = *(void**)((uint64_t)_ + 0x13C);
    Items.newshedkey = *(void**)((uint64_t)_ + 0x148);
    Items.newpadlockkey = *(void**)((uint64_t)_ + 0x154);
    Items.newgencable = *(void**)((uint64_t)_ + 0x160);
    Items.newcoconuty = *(void**)((uint64_t)_ + 0x170);
    Items.newweaponkey = *(void**)((uint64_t)_ + 0x184);
    Items.newcoin = *(void**)((uint64_t)_ + 0x19C);
    Items.newelectricSwitch = *(void**)((uint64_t)_ + 0x1AC);
    Items.newtrainkey = *(void**)((uint64_t)_ + 0x1B8);
    Items.newaccelerator = *(void**)((uint64_t)_ + 0x1C4);
    Items.newdoorActivator = *(void**)((uint64_t)_ + 0x1D0);
    Items.newcrowbar = *(void**)((uint64_t)_ + 0x1E8);

    //public GameObject player; // 0x40
    void* player = *(void**)((uint64_t)_ + 0x14);

    if (SpawnButtonClicked) {
        SpawnItem(player);
        SpawnButtonClicked = false;
    }

    old_PickUp_Update(_);
}





typedef void (*tFixedUpdate)(void* _this);
typedef void (*tGrannyHitByGun)(void* _this);

tFixedUpdate original_FixedUpdate = nullptr;
tGrannyHitByGun grannyHitByGun = nullptr;

// Mod toggle
bool GrannyShot = false;  // Default is false

// Time tracking
clock_t lastShotTime = 0;
const double SHOOT_INTERVAL = 5.0; // 5 seconds

// Hooked FixedUpdate function
void hooked_FixedUpdate(void* _this) {
    // Call the original FixedUpdate function
    if (original_FixedUpdate) original_FixedUpdate(_this);

    // Check if mod is enabled
    if (GrannyShot && grannyHitByGun) {
        clock_t currentTime = clock();
        double elapsed = double(currentTime - lastShotTime) / CLOCKS_PER_SEC;

        // Shoot Granny every 5 seconds
        if (elapsed >= SHOOT_INTERVAL) {
            grannyHitByGun(_this);
            __android_log_print(ANDROID_LOG_INFO, "MOD", "Granny got shot!");

            // Update last shot time
            lastShotTime = currentTime;
        }
    }
}




bool chams = false, shading = false, wireframe = false, glow = false, outline = false, rainbow = false;

bool GodMode = false;


void (*old_GodMode)(void *instance);
void _GodMode(void *instance) {
    if (instance != NULL) {
        if (GodMode) {
            *(bool *) ((uint64_t) instance + 0x10) = false;
			*(bool *) ((uint64_t) instance + 0x11) = false;
			*(bool *) ((uint64_t) instance + 0x12) = false;
			*(bool *) ((uint64_t) instance + 0x13) = false;
			*(bool *) ((uint64_t) instance + 0x14) = false;
			*(bool *) ((uint64_t) instance + 0x15) = false;
			*(bool *) ((uint64_t) instance + 0x16) = false;
			*(bool *) ((uint64_t) instance + 0x17) = false;
			
        }
    }
    return old_GodMode(instance);
}

bool Ammo = false;

void (*old_Ammo)(void *instance);
void _Ammo(void *instance) {
    if (instance != NULL) {
        if (Ammo) {
            *(float *) ((uint64_t) instance + 0xC) = 2.0f;
			
        }
    }
    return old_Ammo(instance);
}



// we will run our hacks in a new thread so our while loop doesn't block process main thread
void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));
    ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap(targetLibName);
        sleep(1);
    } while (!il2cppMap.isValid() && mlovinit());
    setShader("_MainTex");
    LogShaders();
    Wallhack();

    //Check if target lib is loaded
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));

    //Anti-lib rename
    /*
    do {
        sleep(1);
    } while (!isLibraryLoaded("libYOURNAME.so"));*/

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);

#if defined(__aarch64__) //To compile this code for arm64 lib only. Do not worry about greyed out highlighting code, it still works
#else //To compile this code for armv7 lib only.
HOOK_LIB("libil2cpp.so", "0x3C247C", _GodMode, old_GodMode);

// Hook FixedUpdate (Replace with actual offset)
    HOOK_LIB("libil2cpp.so", "0x59F5DC", hooked_FixedUpdate, original_FixedUpdate);

	HOOK_LIB("libil2cpp.so", "0x4BA00C", _Ammo, old_Ammo);

	
    // Get grannyHitByGun function pointer (Replace with actual offset)
    grannyHitByGun = (tGrannyHitByGun)KittyMemory::getAbsoluteAddress("libil2cpp.so", 0x5A5EA8);


        //public class Object
        //public static Object Instantiate(Object original, Vector3 position, Quaternion rotation) { }
        Instantiate = (void*(*)(void*, Vector3, Quaternion)) getAbsoluteAddress(targetLibName, 0x949FE8);
        
      //public sealed class GameObject
     // public Transform get_transform() { }
    get_transform_GameObject  =  (void *(*)(void*)) getAbsoluteAddress(targetLibName, 0x96B3EC);
    
    //public class Transform 
    //public Vector3 get_forward() { }
    get_forward  =  (Vector3(*)(void*)) getAbsoluteAddress(targetLibName, 0xAE11A0);
    
    //public class Transform 
    //public Quaternion get_rotation() { }
    get_rotation  =  (Quaternion(*)(void*)) getAbsoluteAddress(targetLibName, 0xAE09E4);
    
    //public class Transform
    //public Vector3 get_position() { }
	get_position  =  (Vector3(*)(void*)) getAbsoluteAddress(targetLibName, 0xAE0608);
	
	
	// armabi-v7a Hook (x32 bit) 📝
    //public class PickUp 
    //public virtual void Update() { }
    MSHookFunction((void *)getAbsoluteAddress(targetLibName, 0x5CDF8C), (void *)PickUp_Update, (void **)&old_PickUp_Update);
    



    LOGI(OBFUSCATE("Done"));
#endif

    return NULL;
}

//JNI calls
extern "C" {

// Do not change or translate the first text unless you know what you are doing
// Assigning feature numbers is optional. Without it, it will automatically count for you, starting from 0
// Assigned feature numbers can be like any numbers 1,3,200,10... instead in order 0,1,2,3,4,5...
// ButtonLink, Category, RichTextView and RichWebView is not counted. They can't have feature number assigned
// Toggle, ButtonOnOff and Checkbox can be switched on by default, if you add True_. Example: CheckBox_True_The Check Box
// To learn HTML, go to this page: https://www.w3schools.com/

JNIEXPORT jobjectArray
JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_getFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    //Toasts added here so it's harder to remove it
    MakeToast(env, context, OBFUSCATE("Modded by Costillo"), Toast::LENGTH_LONG);

    const char *features[] = {
    "Category_Chams Menu︎", //0
            "1_Toggle_Default Chams",//1
            "2_Toggle_Shading Chams", //2
            "3_Toggle_Wireframe Chams",//3
            "4_Toggle_Glow Chams",//4
            "5_Toggle_Outline Chams", //5
            "6_Toggle_Rainbow Chams", //6
            "7_SeekBar_Line Width_0_12",//7
            "8_SeekBar_Color R_0_255",//8
            "9_SeekBar_Color G_0_255",//9
            "10_SeekBar_Color B_0_255",//10   
			OBFUSCATE("11_Toggle_God Mode"),
			OBFUSCATE("12_Toggle_Granny get Shot"),
			// Menu Code ✅
OBFUSCATE("Collapse_Items"),
OBFUSCATE("13_CollapseAdd_Spinner_Select Item_Off,Gate Fuse, Shotgun, Teddy, Matches, Firewood, Bridge Crank, Plank, Safe Key, Slingshot, Vase, Vase2, Shed Key, Padlock Key, Generator Cable, Coconut, Weapon Key, Coin, Electric Switch, Train Key, Accelerator, Door Activator, Crowbar"),
OBFUSCATE("14_CollapseAdd_Button_Spawn Items"),
			OBFUSCATE("15_Toggle_Unlimited Ammo"),
			
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    pthread_t ptid;
    pthread_create(&ptid, NULL, antiLeech, NULL);

    return (ret);
}

JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_Preferences_Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean boolean, jstring str) {

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         env->GetStringUTFChars(featName, 0), value,
         boolean, str != NULL ? env->GetStringUTFChars(str, 0) : "");

    //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;

    switch (featNum) {
        case 1:
        chams = boolean;
        if (chams) {
        SetWallhack(true);
        } else {
        SetWallhack(false);
        }
        break;
        case 2:
        shading = boolean;
        if (shading) {
        SetWallhackS(true);
        } else {
        SetWallhackS(false);
        }
        break;
        case 3:
        wireframe = boolean;
        if (wireframe) {
        SetWallhackW(true);  
        } else {
        SetWallhackW(false);  
        }
        break;       
        case 4:
        glow = boolean;
        if (glow) {
        SetWallhackG(true);
        } else {
        SetWallhackG(false);
        }
        break;        
        case 5:
        outline = boolean;
        if (outline) {
        SetWallhackO(true); 
        } else {
        SetWallhackO(false);
        }
        break;        
        case 6:
        rainbow = boolean;
        if (rainbow) {
        SetRainbow(true);
        } else {
        SetRainbow(false);
        }
        break;      
        case 7:
        SetW(value);
        break;         
        case 8:
        SetR(value);
        break;
        case 9:
        SetG(value);
        break;
        case 10:
        SetB(value);
        break; 
		
		case 11:
 		GodMode = boolean;
		PATCH_LIB_SWITCH("libil2cpp.so", "0x5A73AC", "00 00 A0 E3 1E FF 2F E1", boolean);
		PATCH_LIB_SWITCH("libil2cpp.so", "0x3F89D4", "00 00 A0 E3 1E FF 2F E1", boolean);
		PATCH_LIB_SWITCH("libil2cpp.so", "0x5A5DE8", "00 00 A0 E3 1E FF 2F E1", boolean);
		PATCH_LIB_SWITCH("libil2cpp.so", "0x3F71D4", "00 00 A0 E3 1E FF 2F E1", boolean);
		 break;
		 
		case 12:
			GrannyShot = boolean;
			break;
		
		case 13:
    switch (value) {
        case 0:
            SelectedItem = NULL;
            break;
        case 1:
            SelectedItem = Items.newgatefuse;
            break;
        case 2:
            SelectedItem = Items.newshotgun;
            break;
        case 3:
            SelectedItem = Items.newteddy;
            break;
        case 4:
            SelectedItem = Items.newmatches;
            break;
        case 5:
            SelectedItem = Items.newfirewood;
            break;
        case 6:
            SelectedItem = Items.newbridgecrank;
            break;
        case 7:
            SelectedItem = Items.newplanka;
            break;
        case 8:
            SelectedItem = Items.newsafekey;
            break;
        case 9:
            SelectedItem = Items.newslingshot;
            break;
        case 10:
            SelectedItem = Items.newvas;
            break;
        case 11:
            SelectedItem = Items.newvas2;
            break;
        case 12:
            SelectedItem = Items.newshedkey;
            break;
        case 13:
            SelectedItem = Items.newpadlockkey;
            break;
        case 14:
            SelectedItem = Items.newgencable;
            break;
        case 15:
            SelectedItem = Items.newcoconuty;
            break;
        case 16:
            SelectedItem = Items.newweaponkey;
            break;
        case 17:
            SelectedItem = Items.newcoin;
            break;
        case 18:
            SelectedItem = Items.newelectricSwitch;
            break;
        case 19:
            SelectedItem = Items.newtrainkey;
            break;
        case 20:
            SelectedItem = Items.newaccelerator;
            break;
        case 21:
            SelectedItem = Items.newdoorActivator;
            break;
        case 22:
            SelectedItem = Items.newcrowbar;
            break;
    }
    break;
			
	case 14:
	SpawnButtonClicked = true;
	break;
	
	case 15:
		Ammo = boolean;
		break;
			
    }
    
}
}

//No need to use JNI_OnLoad, since we don't use JNIEnv
//We do this to hide OnLoad from disassembler
__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}

/*
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);
    return JNI_VERSION_1_6;
}
 */
